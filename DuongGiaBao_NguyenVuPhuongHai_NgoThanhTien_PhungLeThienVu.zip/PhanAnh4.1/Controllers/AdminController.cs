﻿using Microsoft.AspNetCore.Mvc;
using PhanAnh4._1.Data;
using PhanAnh4._1.Models;
using System.Linq;

namespace PhanAnh4._1.Controllers
{
    public class AdminController : Controller
    {
        // /admin
        public IActionResult Index()
        {
            return View(PhanAnhRepository.DanhSach);
        }

        // /admin/details/{id}
        public IActionResult Details(int id)
        {
            var pa = PhanAnhRepository.DanhSach.FirstOrDefault(x => x.Id == id);
            return View("~/Views/Shared/ChiTiet.cshtml", pa);
        }

        // /admin/update/{id}
        public IActionResult Update(int id)
        {
            var pa = PhanAnhRepository.DanhSach
                .FirstOrDefault(x => x.Id == id);

            if (pa == null) return NotFound();

            return View(pa);
        }

        [HttpPost]
        public IActionResult Update(int id, string ketQua)
        {
            var pa = PhanAnhRepository.DanhSach
                .FirstOrDefault(x => x.Id == id);

            if (pa == null) return NotFound();

            pa.KetQua = ketQua;
            pa.DaXuLy = true;

            return RedirectToAction("Index");
        }

        // /admin/delete/{id}
        public IActionResult Delete(int id)
        {
            var pa = PhanAnhRepository.DanhSach
                .FirstOrDefault(x => x.Id == id);

            if (pa != null)
            {
                PhanAnhRepository.DanhSach.Remove(pa);
            }

            return RedirectToAction("Index");
        }
    }
}
