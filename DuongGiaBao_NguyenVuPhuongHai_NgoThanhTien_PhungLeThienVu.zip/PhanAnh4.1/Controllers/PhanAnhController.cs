﻿using Microsoft.AspNetCore.Mvc;
using PhanAnh4._1.Models;
using PhanAnh4._1.Data;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace PhanAnh4._1.Controllers
{
    public class PhanAnhController : Controller
    {
        // GET: /phananh
        public IActionResult Index()
        {
            ViewBag.Id = PhanAnhRepository.TaoId();
            return View();
        }

        // POST: /phananh
        [HttpPost]
        [HttpPost]
        public IActionResult Index(PhanAnh pa, List<IFormFile> files)
        {
            if (files == null || files.Count == 0)
            {
                ModelState.AddModelError("", "Không nhận được file hoặc file quá lớn (>30MB).");
                ViewBag.Id = PhanAnhRepository.TaoId(); // Load lại ID cho View
                return View(pa);
            }

            if (pa == null) pa = new PhanAnh();

            pa.Id = PhanAnhRepository.TaoId();
            pa.DaXuLy = false;
            pa.DanhSachFile = new List<string>();

            // Kiểm tra số lượng file
            if (files.Count > 3)
            {
                ModelState.AddModelError("", "Bạn chỉ được phép tải lên tối đa 3 file.");
                ViewBag.Id = pa.Id;
                return View(pa);
            }

            string folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/phananh");
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

            foreach (var file in files)
            {
                // 2. Kiểm tra dung lượng (30MB = 30 * 1024 * 1024 bytes)
                if (file.Length > 30 * 1024 * 1024)
                {
                    ModelState.AddModelError("", $"File {file.FileName} quá lớn (tối đa 30MB).");
                    continue;
                }

                string fileName = $"{pa.Id}_{Guid.NewGuid()}_{file.FileName}";
                string path = Path.Combine(folder, fileName);

                using (var stream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
                pa.DanhSachFile.Add(fileName);
            }

            PhanAnhRepository.DanhSach.Add(pa);
            return RedirectToAction("CamOn", new { id = pa.Id });
        }

        // /phananh/camon
        public IActionResult CamOn(int id)
        {
            ViewBag.Id = id;
            return View();
        }

        // /phananh/chitiet/{id}
        public IActionResult ChiTiet(int id)
        {
            var pa = PhanAnhRepository.DanhSach.FirstOrDefault(x => x.Id == id);
            return View(pa);
        }
    }
}
