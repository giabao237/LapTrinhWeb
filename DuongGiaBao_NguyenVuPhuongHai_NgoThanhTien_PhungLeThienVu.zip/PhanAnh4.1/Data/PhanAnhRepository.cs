﻿using PhanAnh4._1.Models;

namespace PhanAnh4._1.Data
{
    public static class PhanAnhRepository
    {
        public static List<PhanAnh> DanhSach = new List<PhanAnh>();

        public static int TaoId()
        {
            return DanhSach.Count == 0 ? 1 : DanhSach.Max(x => x.Id) + 1;
        }
    }
}
