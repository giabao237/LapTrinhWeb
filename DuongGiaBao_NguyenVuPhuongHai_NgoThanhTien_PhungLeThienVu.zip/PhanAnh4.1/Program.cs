﻿var builder = WebApplication.CreateBuilder(args);

// --- 1. ĐĂNG KÝ DỊCH VỤ (Tất cả builder.Services phải nằm ở đây) ---
builder.Services.AddControllersWithViews();

// Cấu hình giới hạn 40MB để hỗ trợ video 30MB
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 40 * 1024 * 1024;
});

var app = builder.Build(); // CHỐT SỔ DỊCH VỤ - KHÔNG ĐƯỢC builder.Services sau dòng này

// --- 2. CẤU HÌNH PIPELINE (Middleware) ---
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=PhanAnh}/{action=Index}/{id?}");

app.Run();