﻿namespace PhanAnh4._1.Models
{
    public class PhanAnh
    {
        public int Id { get; set; }
        public string TieuDe { get; set; }
        public string NoiDung { get; set; }
        public List<string> DanhSachFile { get; set; } = new List<string>();
        public DateTime ThoiGian { get; set; }
        public bool DaXuLy { get; set; }
        public string KetQua { get; set; }
    }
}
